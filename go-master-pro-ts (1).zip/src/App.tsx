import React from 'react';
import GoGame from './GoGame';

function App() {
  return <GoGame />;
}

export default App;