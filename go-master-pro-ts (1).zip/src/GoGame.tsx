import React from 'react';

// Đây là component GoGame.tsx mẫu để bạn thay thế bằng code thật của bạn
const GoGame: React.FC = () => {
  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <h1 className="text-2xl font-bold text-gray-800">
        Go Game Component Placeholder
      </h1>
    </div>
  );
};

export default GoGame;