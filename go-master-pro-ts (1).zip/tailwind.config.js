/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      animation: {
        'float': 'float 3s ease-in-out infinite',
        'glow': 'glow 2s ease-in-out infinite',
        'slideUp': 'slideUp 0.4s ease-out',
        'slideLeft': 'slideLeft 0.4s ease-out',
        'slideRight': 'slideRight 0.4s ease-out',
        'neonGlow': 'neonGlow 2s ease-in-out infinite',
        'boardGlow': 'boardGlow 3s ease-in-out infinite',
        'starPulse': 'starPulse 2s ease-in-out infinite',
        'gradientShift': 'gradientShift 8s ease infinite',
        'backgroundFloat': 'backgroundFloat 20s ease-in-out infinite',
      },
    },
  },
  plugins: [],
}