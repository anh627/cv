# Go Master Pro (TypeScript)

A professional Go (Weiqi/Baduk) game built with React + TypeScript featuring:

## Features
- 🎮 Multiple board sizes (9x9, 13x13, 19x19)
- 🤖 AI opponent with 3 difficulty levels
- 👥 Local multiplayer mode
- ⏱️ Timer for each move
- 📊 Score calculation
- 🎯 Ko rule implementation
- 💫 Beautiful animations and UI

## Technologies
- React 18 + TypeScript
- Tailwind CSS
- Advanced AI with Minimax algorithm
- Responsive design

## Deploy to Netlify

[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start/deploy?repository=YOUR_GITHUB_REPO_URL)

## Local Development
```bash
npm install
npm start
```

## Build for Production
```bash
npm run build
```

## License
MIT
